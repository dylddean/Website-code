// <?php
// require_once("../stripe-php-master/init.php");

// // if (isset($_POST["submit"])) {

// // First we get the form data from the URL

// $id = $_POST["id"];
// $etr_amt = $_POST["amount"];


// $token = $_POST["stripeToken"];
// $tokenemail = $_POST["stripeEmail"];
// $tokentype = $_POST["stripeTokenType"];

// $publishablekey = 'pk_live_51MiJijCwIR0GP1QUCcvkGEjMEeFycNieg4pojNSsnSDQyYQNWnkeiYBEEz6TiYyaJCXT3lFOxh3FlCtEUxyotOCF00p0lg6hNd';
// $secretkey = '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';
// $pk = trim($publishablekey);
// $sk = trim($secretkey);
// // echo '<pre>';
// // print_r($_POST);
// \Stripe\Stripe::setApiKey($sk);
// $customer = $stripe->customers->create();
// echo $customer->getLastResponse()->headers["Request-Id"];

// \Stripe\Stripe::setApiKey($sk);
// $stripe->financialConnections->sessions->create([
//   'account_holder' => [
//     'type' => 'customer',
//     echo $customer->getLastResponse()->headers["Request-Id"]
//   ],
//   'permissions' => ['payment_method', 'balances'],
//   'filters' => ['countries' => ['US']],
// ]);

// \Stripe\Stripe::setApiKey($sk);
// $stripe = new \Stripe\StripeClient($sk);
// $charge = $stripe->sources->create([
//     'type' => 'ach_credit_transfer',
//     'currency' => 'usd',
//     'owner' => ['email' => $tokenemail],
// ]);

// $stripe = new \Stripe\StripeClient($sk);
// $stripe->sources->retrieve(
//   '',
//   []
// );

// $stripe = new \Stripe\StripeClient($sk);
// $stripe->sources->update(
//   '',
//   ['metadata' => ['order_id' => '6735']]
// );

// $stripe->customers->create([
//   'description' => 'My First Test Customer (created for API docs at https://www.stripe.com/docs/api)',
// ]);


// $stripe = new \Stripe\StripeClient($sk);
// $stripe->customers->createSource(
//   '',
//   [
//     'source' => '',
//   ]
// );

// $stripe = new \Stripe\StripeClient($sk);
// $stripe->customers->deleteSource(
//   '',
//   ''
// );

// $arr = json_decode(json_encode($charge), true);

// $enter_amount = $etr_amt;
// $pay_id = $arr["id"];
// $object = $arr["object"];
// $currency = $arr["currency"];
// $flow = $arr["flow"];
// $reciver_address = $arr["receiver"]["address"];
// $amount_received = $arr["receiver"]["amount_received"];
// $amount_charged = $arr["receiver"]["amount_charged"];
// $account_number = $arr["ach_credit_transfer"]["account_number"];
// $routing_number = $arr["ach_credit_transfer"]["routing_number"];
// $fingerprint = $arr["ach_credit_transfer"]["fingerprint"];
// $bank_name = $arr["ach_credit_transfer"]["bank_name"];
// $swift_code = $arr["ach_credit_transfer"]["swift_code"];
// $owner_email = $arr["owner"]["email"];
// $status = $arr["status"];
// $type = $arr["type"];
// $usage_type = $arr["usage"];
// // Then we run a bunch of error handlers to catch any user mistakes we can (you can add more than I did)
// // These functions can be found in functions.inc.php
// require_once "dbh.inc.php";
// require_once 'functions.inc.php';

// // If we get to here, it means there are no user errors
// // Now we insert the user into the database
// if ($charge) {
//     updateUser($conn, $id, $enter_amount, $pay_id, $object, $currency, $flow, $reciver_address, $amount_received, $amount_charged, $account_number, $routing_number, $fingerprint, $bank_name, $swift_code, $owner_email, $status, $type, $usage_type);
//     echo '<script>alert("Payment Succesfully & Registration Successfully"); window.location.href="../buy.php";</script>';
//     exit();
// } else {
//     header("location: ../signup.php");
//     exit();
// }

?>
<?php
require_once("../stripe-php-master/init.php");

// if (isset($_POST["submit"])) {

// First we get the form data from the URL

$id = $_POST["id"];
$etr_amt = $_POST["amount"];


$token = $_POST["stripeToken"];
$tokenemail = $_POST["stripeEmail"];
$tokentype = $_POST["stripeTokenType"];

$publishablekey = 'pk_test_51MiJijCwIR0GP1QUtZsY4WeQRGCucPgGI6wL8fQD2264ODYv3JOU7x5o3tyP7Xf5ESqDu7OcA0ef5Do6a9er068n00GRqfLonf';
$secretkey = 'sk_test_51MiJijCwIR0GP1QUiemhoHF3RnJNA2lcQqfpvbXuwJWVV1PaYLanfeMSNeIbyu0YCQxTuuIM97NSOD3SLGQqdgPN00OWhhFTpA';
// $publishablekey = 'pk_live_51MiJijCwIR0GP1QUCcvkGEjMEeFycNieg4pojNSsnSDQyYQNWnkeiYBEEz6TiYyaJCXT3lFOxh3FlCtEUxyotOCF00p0lg6hNd';
// $secretkey = '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';
$pk = trim($publishablekey);
$sk = trim($secretkey);
// echo '<pre>';
// print_r($_POST);
// exit();
\Stripe\Stripe::setApiKey($sk);
$stripe = new \Stripe\StripeClient($sk);
$charge = $stripe->sources->create([
    'type' => 'ach_credit_transfer',
    'currency' => 'usd',
    'owner' => ['email' => $tokenemail],
]);

$arr = json_decode(json_encode($charge), true);


$enter_amount = $etr_amt;
$pay_id = $arr["id"];
$object = $arr["object"];
$currency = $arr["currency"];
$flow = $arr["flow"];
$amount= $arr["amount"] = $etr_amt;
$reciver_address = $arr["receiver"]["address"];
$amount_received = $arr["receiver"]["amount_received"];
$amount_charged = $arr["receiver"]["amount_charged"];
$account_number = $arr["ach_credit_transfer"]["account_number"];
$routing_number = $arr["ach_credit_transfer"]["routing_number"];
$fingerprint = $arr["ach_credit_transfer"]["fingerprint"];
$bank_name = $arr["ach_credit_transfer"]["bank_name"];
$swift_code = $arr["ach_credit_transfer"]["swift_code"];
$owner_email = $arr["owner"]["email"];
$status = $arr["status"];
$type = $arr["type"];
$usage_type = $arr["usage"];
// Then we run a bunch of error handlers to catch any user mistakes we can (you can add more than I did)
// These functions can be found in functions.inc.php
require_once "dbh.inc.php";
require_once 'functions.inc.php';
// echo '<pre>';
// print_r($charge);
// exit();
// If we get to here, it means there are no user errors
// Now we insert the user into the database
if ($charge) {
    
    $sql = "UPDATE users SET enter_amount='$enter_amount', amount='$amount', pay_id='$pay_id', object='$object', currency='$currency', flow='$flow', reciver_address='$reciver_address', amount_received='$amount_received', amount_charged='$amount_charged', account_number='$account_number', routing_number='$routing_number', fingerprint='$fingerprint', bank_name='$bank_name', swift_code='$swift_code', owner_email='$owner_email', status='$status', type='$type', usage_type='$usage_type' WHERE id=$id";

	$stmt = mysqli_stmt_init($conn);
	if (!mysqli_stmt_prepare($stmt, $sql)) {
		header("location: ../signup.php?error=stmtfailed");
		exit();
	}
	mysqli_stmt_execute($stmt);
	mysqli_stmt_close($stmt);
	mysqli_close($conn);
	echo '<script>alert("Payment Succesfully & Registration Successfully");</script>';
    echo '<script>window.location.href="../buy.php";</script>';
	exit();
    // updateUser($conn, $id, $enter_amount, $amount, $pay_id, $object, $currency, $flow, $reciver_address, $amount_received, $amount_charged, $account_number, $routing_number, $fingerprint, $bank_name, $swift_code, $owner_email, $status, $type, $usage_type);
    // echo '<script>alert("Payment Succesfully & Registration Successfully");</script>';
    // echo '<script>window.location.href="../buy.php";</script>';
    // exit();
} else {
    header("location: ../signup.php");
    exit();
}
