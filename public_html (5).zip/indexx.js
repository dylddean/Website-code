async function connectWallet() {
   accounts = await window.ethereum.request({method: "eth_requestAccounts"}).catch((err)=>{
   console.log(err.code)
})
}