<?php

$servername = "mysql";
$dBUsername = "u464426980_ddylddean";
$dBPassword = "Wolfman7005$";
$dBName = "u464426980_Wheneverdean";

$conn = mysqli_connect($servername, $dBUsername, $dBPassword, $dBName);

if (!$conn) {
	die("Connection failed: ".mysqli_connect_error());
}
