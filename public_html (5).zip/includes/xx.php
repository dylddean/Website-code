<?php 
echo '<script>alert("Payment Succesfully & Registration Successfully");</script>';
echo '<script>window.location.href="../buy.php";</script>';
?>