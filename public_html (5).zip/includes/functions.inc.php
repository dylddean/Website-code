<?php

// Check for empty input signup
function emptyInputSignup($name, $email, $username, $pwd, $pwdRepeat) {
	$result;
	if (empty($name) || empty($email) || empty($username) || empty($pwd) || empty($pwdRepeat)) {
		$result = true;
	}
	else {
		$result = false;
	}
	return $result;
}

// Check invalid username
function invalidUid($username) {
	$result;
	if (!preg_match("/^[a-zA-Z0-9]*$/", $username)) {
		$result = true;
	}
	else {
		$result = false;
	}
	return $result;
}

// Check invalid email
function invalidEmail($email) {
	$result;
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		$result = true;
	}
	else {
		$result = false;
	}
	return $result;
}

// Check if passwords matches
function pwdMatch($pwd, $pwdrepeat) {
	$result;
	if ($pwd !== $pwdrepeat) {
		$result = true;
	}
	else {
		$result = false;
	}
	return $result;
}

// Check if username is in database, if so then return data
function uidExists($conn, $username) {
	$sql = "SELECT * FROM users WHERE usersUid = '".$username."' OR usersEmail = '".$username."';";
	  $stmt = mysqli_stmt_init($conn);
	  if (!mysqli_stmt_prepare($stmt, $sql)) {
		   header("location: ../signup.php?error=stmtfailed");
		  exit();
	  }

	mysqli_stmt_bind_param($stmt, "ss", $username, $username);
	mysqli_stmt_execute($stmt);

	// "Get result" returns the results from a prepared statement
	$resultData = mysqli_stmt_get_result($stmt);

	if ($row = mysqli_fetch_assoc($resultData)) {
		session_start();
		$_SESSION["usersEmail"] = $row['usersEmail'];
		return $row;
	}
	else {
		$result = false;
		return $result;
	}

	mysqli_stmt_close($stmt);
}

// Insert new user into database
function createUser($conn, $name, $email, $username, $pwd) {
  $sql = "INSERT INTO users (usersName, usersEmail, usersUid, usersPwd) VALUES (?, ?, ?, ?);";

	$stmt = mysqli_stmt_init($conn);
	if (!mysqli_stmt_prepare($stmt, $sql)) {
	 	header("location: ../signup.php?error=stmtfailed");
		exit();
	}

	$hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);

	mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $username, $hashedPwd);
	mysqli_stmt_execute($stmt);
	mysqli_stmt_close($stmt);
	mysqli_close($conn);
	header("location: ../login.php?error=none");
	exit();
}

function updateUser($conn, $id, $enter_amount, $amount, $pay_id, $object, $currency, $flow, $reciver_address, $amount_received, $amount_charged, $account_number, $routing_number, $fingerprint, $bank_name, $swift_code, $owner_email, $status, $type, $usage_type)
{

	$sql = "UPDATE users SET enter_amount='$enter_amount', amount='$amount', pay_id='$pay_id', object='$object', currency='$currency', flow='$flow', reciver_address='$reciver_address', amount_received='$amount_received', amount_charged='$amount_charged', account_number='$account_number', routing_number='$routing_number', fingerprint='$fingerprint', bank_name='$bank_name', swift_code='$swift_code', owner_email='$owner_email', status='$status', type='$type', usage_type='$usage_type' WHERE id=$id";

	$stmt = mysqli_stmt_init($conn);
	if (!mysqli_stmt_prepare($stmt, $sql)) {
		header("location: ../signup.php?error=stmtfailed");
		exit();
	}
	// mysqli_stmt_bind_param($stmt, "sssssssssssssssss", $pay_id, $object, $currency, $flow, $reciver_address, $amount_received, $amount_charged, $account_number, $routing_number, $fingerprint, $bank_name, $swift_code, $owner_email, $status, $type, $usage_type);
	mysqli_stmt_execute($stmt);
	mysqli_stmt_close($stmt);
	mysqli_close($conn);
// 	echo '<script>alert("Payment Succesfully & Registration Successfully");</script>';
//  echo '<script>window.location.href="../buy.php";</script>';
// 	header("location: ../buy.php");
    header("location: xx.php");
	exit();
}

// Check for empty input login
function emptyInputLogin($username, $pwd) {
	$result;
	if (empty($username) || empty($pwd)) {
		$result = true;
	}
	else {
		$result = false;
	}
	return $result;
}
function loginUser($conn, $username, $pwd) {
	$uidExists = uidExists($conn, $username);

	// echo "<pre>";
	// print_r($uidExists) ;
	// die;

	if ($uidExists === false) {
		header("location: ../login.php?error=wronglogin");
		exit();
	}

	$pwdHashed = $uidExists["usersPwd"];
	$checkPwd = password_verify($pwd, $pwdHashed);

	if ($checkPwd === false) {
		header("location: ../login.php?error=wronglogin");
		exit();
	}
	else if ($checkPwd === true) {
		session_start();
		$_SESSION["userid"] = $uidExists["id"];

		$_SESSION["useruid"] = $uidExists["usersUid"];
		header("location: ../dash.php?loginsuccessful");
		exit();
	}

}

function createOrder($amount) {
	
	session_start();
	$_SESSION["order_amount"] = $amount;
	$service_fee = ($amount * 3 / 100);
	$_SESSION["service_fee"] = $service_fee;
	header("location: ../checkout.php");
	exit();

}


