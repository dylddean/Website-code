<?php
  session_start();

  if (isset($_SESSION["order_amount"])) {
    unset($_SESSION['order_amount']);
    unset($_SESSION['service_fee']);
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Payment Status</title>
    <meta name="description" content="Payment on Stripe" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="stripe_payment/checkout.css" />
    <script src="https://js.stripe.com/v3/"></script>
    <script src="stripe_payment/checkout.js" defer></script>
  </head>
  <body>
    <!-- Display a payment form -->
    <form id="payment-form">
      <div id="payment-message" class="hidden"></div>
      <?php
        // header("'Refresh: 10;location: ../dash.php");
        header( "refresh:3;url=dash.php" );
        exit();
      ?>
    </form>
  </body>
</html>